public class Cantor {
    String nome;
    String nacionalidade;

    public Cantor(String nome, String nacionalidade) {
        this.nome = nome;
        this.nacionalidade = nacionalidade;
    }

    public String getDados() {
        return "Nome: " +nome+ ", Nacionalidade: " +nacionalidade;
    }
}
