public class Main {
    public static void main(String[] args) {
        Cantor c1 = new Cantor("João Dequech", "Brasil");
        Cantor c2 = new Cantor("Charlie Brown", "Brasil");
        Cantor c3 = new Cantor("Caetano Veloso", "Brasil");
        Cantor c4 = new Cantor("Pablo Vittar", "Brasil");
    
        Musica m1 = new Musica("Capivaras Mutantes", "Gospel", c1.nome, 0);
        Musica m2 = new Musica("Zoio de Lula", "Rock", c2.nome, 0);
        Musica m3 = new Musica("Eu nasci", "Lula", c3.nome, 0);
        Musica m4 = new Musica("Sei la", "Drag", c4.nome, 0);


        Playlist p = new Playlist(4);

        p.inserir(m1);
        p.inserir(m2);
        p.inserir(m3);
        p.inserir(m4);

        p.tocar("Sei la");
        p.tocar("Zoio de Lula");

        System.out.println("");

        p.listar();
    }
}