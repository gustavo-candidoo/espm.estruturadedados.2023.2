public class Musica {

    String titulo;
    String genero;
    String cantor;
    int total;
    int indice;

    public Musica(String titulo, String genero, String cantor, int total) {
        this.titulo = titulo;
        this.genero = genero;
        this.total = total;
        this.cantor = cantor;
    }

    public String getDados() {
        return "Título: " +titulo+ ", Gênero: " +genero+ ", Cantor: " +cantor+ ", Total: " +total;
    }

}
