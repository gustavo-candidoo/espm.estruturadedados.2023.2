import java.util.ArrayList;
import java.util.List;

public class Playlist {
    
    List<Musica> musicas; 
    int indice;

    public Playlist(int len){
        this.indice = 1;
        this.musicas = new ArrayList<>();
    }

    public void inserir(Musica musica) {
        musica.indice = indice++;
        musicas.add(musica);
    }   

    public void tocar(String titulo) {
        for(int i = 0; i < musicas.size(); i++) {
            Musica musica = musicas.get(i);
            if(musica.titulo.equals(titulo)) {
                System.out.println("Ouvindo agora: " +musica.titulo);
                musica.total++;
                return;
            }
        }
        System.out.println("A música não existe na playlist.");
        
    }

    public void listar() {
        for(int i = 0; i < musicas.size(); i++) {
            Musica musica = musicas.get(i);
            System.out.println(musica.getDados() + "\n");
        }
    }
}

