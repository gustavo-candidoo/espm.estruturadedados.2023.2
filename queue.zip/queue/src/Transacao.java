import java.util.LinkedList;
import java.util.Queue;

public class Transacao {
    private Queue<Acao> carteira = new LinkedList<>();

    public void comprar(Acao acao) {
        carteira.add(acao);
    }

    public double vender(int quantidade, double valorVenda) {
        return 0;
    }
}
